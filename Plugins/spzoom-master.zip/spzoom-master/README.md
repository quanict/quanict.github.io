spzoom
======

> simple jQuery image zoomer.

See <http://spajak.github.io/spzoom/> for demos and options.
'use strict';

var angular = require('angular');
var moment = require('moment');

angular
  .module('mwl.calendar')
  .constant('moment', moment);
